#include "Arduino.h"

//#define DEBUG_PORT 0
//#define DEBUG_PIN  17
#include "debug_macros.h"

void setup(void)
{
}

void loop(void)
{
}
